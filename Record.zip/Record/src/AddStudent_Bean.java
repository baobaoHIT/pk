
public class AddStudent_Bean {
	
	private int studentID;
    private String studentName;
    private int classID;
    
    public int getStudentID()
    {
        return studentID;
    }
    public String getStudentName()
    {
        return studentName;
    }
    public int getClassID()
    {
        return classID;
    }
    public void setStudentID(int studentID)
    {
        this.studentID = studentID;
    }
    public void setStudentName(String studentName)
    {
        this.studentName = studentName;
    }
    public void setClassID(int classID)
    {
        this.classID = classID;
    }

}
